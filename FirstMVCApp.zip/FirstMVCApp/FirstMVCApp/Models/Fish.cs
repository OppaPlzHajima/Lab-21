﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstMVCApp.Models
{
    public class Fish
    {
        public string Name { get; set; }
        public int Scales { get; set; }
        public string Species { get; set; }
        public bool IsFreshWater { get; set; }
    }
}
